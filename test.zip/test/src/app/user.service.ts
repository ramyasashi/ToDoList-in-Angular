import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './user';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }
  url = "https://api.github.com/users/octocat/followers";

  getUsersList(): Observable<User[]> {
   return this.http.get<User[]>(this.url);
  }
  // getEmployees(): Observable<Employee[]> {
  //   return this.http.get<Employee[]>(this.url);
  //  // return this.employeeSubject.next(this.http.get<Employee[]>(this.url));
  // }
}
