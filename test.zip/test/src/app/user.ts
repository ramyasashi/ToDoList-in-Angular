export class User {
    login: string;
    id: number;
    type: string;
    url: string;
}