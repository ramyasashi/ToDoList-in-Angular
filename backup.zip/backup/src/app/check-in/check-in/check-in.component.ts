import { Component, OnInit, OnDestroy } from '@angular/core';
import { FlightListService } from 'src/app/services/flight-list.service';
import { Subscription, Observable } from 'rxjs';
import { FLIGHTS } from 'src/app/Models/flight_data';
import { Router } from '@angular/router';

@Component({
  selector: 'app-check-in',
  templateUrl: './check-in.component.html',
  styleUrls: ['./check-in.component.scss']
})
export class CheckInComponent implements OnInit, OnDestroy {

  flightList$: Observable<FLIGHTS[]>;
  flightList = [];
  subscription: Subscription;
  constructor(private flightListService: FlightListService, private router: Router) { }

  ngOnInit() {
    this.subscription = this.flightListService.flightSubject.subscribe(data => {
      this.flightList = data;
      console.log(this.flightList);
    });
    // this.flightList$ = this.flightListService.getFlightList();
    // this.flightList$.subscribe(data => console.log(data));
    this.flightListService.getFlightList();
  }
  redirectToFD(id) {
    this.router.navigate(['/lazyModule/', id]);
  }
  ngOnDestroy() {
   // this.subscription.unsubscribe();
  }
}
