import { Component, OnInit, OnDestroy } from '@angular/core';
import { FlightListService } from 'src/app/services/flight-list.service';
import { Subscription } from 'rxjs';
import { FLIGHTS } from 'src/app/Models/flight_data';
import { ActivatedRoute, ParamMap, Params } from '@angular/router';

@Component({
  selector: 'app-flight-details',
  templateUrl: './flight-details.component.html',
  styleUrls: ['./flight-details.component.scss']
})
export class FlightDetailsComponent implements OnInit, OnDestroy {

  flightList = [];
  subscription: Subscription;
  flight: FLIGHTS;
  id: number;
  constructor(private flightListService: FlightListService, private route: ActivatedRoute) { }

  ngOnInit() {
    console.log('detail component');
    // this.flightListService.getPassengerList();
    this.subscription = this.flightListService.flightSubject.subscribe(data => {
      this.flightList = data;
      console.log(this.flightList);
      this.id = +this.route.snapshot.paramMap.get('id');
      console.log(this.id);
      this.flightList.map(value => {
        if (value.id === this.id) {
          this.flight = value;
          console.log(this.flight);
        }
    });
    });
    this.flightListService.getFlightList();
    this.flightListService.getPassengerList();
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
