// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { PassengerDetailsComponent } from './passenger-details.component';
// import { FunctionalService } from 'src/app/services/functional.service';
// import { NO_ERRORS_SCHEMA } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { timer } from 'rxjs';
// import { mapTo } from 'rxjs/operators';
// import { FlightListService } from 'src/app/services/flight-list.service';

// describe('PassengerDetailsComponent', () => {
//   let component: PassengerDetailsComponent;
//   let flightListService: FlightListService;
//   let fixture: ComponentFixture<PassengerDetailsComponent>;
//   const fakePassenger = {  name: 'Ramya',
//     age: 23,
//     flightId: 1543,
//     mobileNumber: 98076543,
//     infants: true,
//     accillaryServices: ['Burger'],
//     seatNumber: 21
// };
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PassengerDetailsComponent ],
//       providers: [FlightListService, {provide: HttpClient, useValue: {}}],
//       schemas: [NO_ERRORS_SCHEMA]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PassengerDetailsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
//   it(`should have a list of users`, (done) => {
//     const spy = spyOn(flightListService, 'getPassengerList').and.returnValue(timer(1000).pipe(mapTo([fakePassenger])));
//     component.ngOnInit();
//     // component.subscription.subscribe(users => {
//     //   console.log(users);
//     //   expect(users).toEqual([fakePassenger]);
//     //   done();
//     // });
//     expect(component.passengersList).toEqual([fakePassenger]);
//     done();
//   });
// });
