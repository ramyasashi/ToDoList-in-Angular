export class User {
  fName: string;
  lName: string;
  password: string;
  mobileNumber: number;
  email: string;
}
