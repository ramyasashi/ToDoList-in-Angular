import { Component, OnInit } from '@angular/core';
import { FacebookLoginProvider, SocialUser } from 'angularx-social-login';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {

  user: SocialUser;
  loggedIn: boolean;
  loggedValue: any;
  hide: boolean;
  signinForm: FormGroup;
  constructor(private formBuilder: FormBuilder, public router: Router, private authService: AuthService) { }

  // signInWithFB(): void {
  //   this.authService.signIn(FacebookLoginProvider.PROVIDER_ID);
  // }
  // signOut(): void {
  //   this.authService.signOut();
  // }
  ngOnInit() {
    this.hide = true;
    this.signinForm = this.formBuilder.group({
      email: ['', [
        Validators.required,
        Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/)
      ]],
    password: ['', [
      Validators.required,
      Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/)
    ]],
    });

  }
  onSubmit(signInForm: FormGroup) {
    console.log('signin');

    // this.router.navigate(['/home']);
    this.loggedValue = this.authService.login(signInForm.value.email, signInForm.value.password);
    console.log(this.loggedValue);
    // this.loggedValue = true;
    if ( this.loggedValue === 'admin') {
      this.router.navigate(['/adminModule']);
    } else if (this.loggedValue === 'staff') {
      this.router.navigate(['/lazyModule']);
    } else {
      alert('Please login again');
      this.router.navigate(['/signin']);
    }
  }

}
