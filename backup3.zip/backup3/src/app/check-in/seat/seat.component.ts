import { Component, OnInit } from '@angular/core';
import { Passenger } from 'src/app/Models/passenger';
import { Store, select } from '@ngrx/store';
import * as PassengerActions from '../../store/actions/passengerList.action';
import { AppState } from '../../store/app.state';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-seat',
  templateUrl: './seat.component.html',
  styleUrls: ['./seat.component.scss']
})
export class SeatComponent implements OnInit {

  bSeatUrl = './assets/bseat.png';
  fSeatUrl = './assets/fseat.png';
  bookSeatUrl = './assets/bookseat.png';
  isValid = true;
  isClicked = true;
  element: HTMLElement;
  passengersList = [];
  passengerList$ : Observable<Passenger[]>
  id: number;
  passengerWF = [];
  num = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26,28, 28, 29, 30 ];
  constructor(private route: ActivatedRoute, private store: Store<AppState>) { }

  ngOnInit() {
    this.id = +this.route.snapshot.paramMap.get('id');
    this.passengerList$ = this.store.pipe(select(store => store.passengerState.list));
      this.store.dispatch(new PassengerActions.PassengerList());
      this.passengerList$.subscribe(data => {
        this.passengersList = data
        for (const person of this.passengersList) {
          if (person.flightId === this.id) {
          this.passengerWF.push(person);
          }
        }
        console.log(this.passengerWF);
        return this.passengerWF;
      });
  }
  seatFun(index: number){
    this.element = document.getElementById('seat-'+index);
    this.element.setAttribute( 'src', './assets/bookseat.png' );
  //   this.element = document.getElementById("imgClickAndChange")
  //     if (this.element.src == "./assets/bseat.png") 
  //     {
  //       this.element.src = "./assets/bookseat.png";
  //     }
  //     else 
  //     {
  //       this.element.src = "./assets/bseat.png";
  //     }
  // }
  }
}
