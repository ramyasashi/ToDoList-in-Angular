import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passengers-list',
  templateUrl: './passengers-list.component.html',
  styleUrls: ['./passengers-list.component.scss']
})
export class PassengersListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
