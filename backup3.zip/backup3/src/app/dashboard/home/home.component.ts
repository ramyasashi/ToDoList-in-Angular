import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { FunctionalService } from 'src/app/services/functional.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  SearchForm: FormGroup;
  number = 1;
  box: boolean;
  incrementValue: number;
  incrementValue2: number;
  states: string[];
  fromValue = '';
  toValue = '';
  constructor(private functionalService: FunctionalService) { }
  // subject = new Subject<any>();
  // openDialog() {
  //   const dialogRef = this.dialog.open(SignupComponent);

  //   dialogRef.afterClosed().subscribe(result => {
  //     console.log(`Dialog result: ${result}`);
  //   });
  // }
  // openDialog1() {
  //   const dialogRef = this.dialog.open(SigninComponent);

  //   dialogRef.afterClosed().subscribe(result => {
  //     console.log(`Dialog result: ${result}`);
  //   });
  // }
  ngOnInit() {
    console.log('home');
    this.box = false;
    this.incrementValue = 0;
    this.incrementValue2 = 0;
    this.states = this.functionalService.states.sort();
  }
  incrementByOne() {
    this.incrementValue++;
  }
  decrementByOne() {
    this.incrementValue--;
  }
  incrementByOne2() {
    this.incrementValue2++;
  }
  decrementByOne2() {
    this.incrementValue2--;
  }
  totalValue() {
    this.number = this.incrementValue + this.incrementValue2;
  }
  Swap_Fun() {
    this.toValue = [this.fromValue, this.fromValue = this.toValue][0];
  }
}
