import { Injectable } from '@angular/core';
import { Actions, Effect , ofType } from '@ngrx/effects';
import { Observable, of} from 'rxjs';
import * as FlightActions from '../../store/actions/flightList.action';
import { FlightListService } from '../../services/flight-list.service';
import { mergeMap, map, catchError } from 'rxjs/operators';
import { FLIGHTS } from '../../Models/flight_data';
import { User } from '../../Models/user';

@Injectable()
export class FlightEffects {
  constructor(
    private actions$: Actions,
    private flightService: FlightListService
  ) {}
  @Effect() getFlightList$ = this.actions$
  .pipe(ofType<FlightActions.FlightList>(FlightActions.FlightListActionTypes.GET_FLIGHT_LIST),
  mergeMap(
    () =>
      this.flightService.getFlightList().pipe(
        map(data => new FlightActions.FlightListSuccess(data)),
        catchError(error => of(new FlightActions.FlightListError(error))))
  )
  );
}
