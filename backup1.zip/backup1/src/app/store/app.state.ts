import { FlightState } from './store/../reducers/flightList.reducer';

export interface AppState {
  flightState: FlightState;
  LoginState: FlightState;
}
