import { NgModule } from '@angular/core';
import { MaterialModule } from '../material/material.module';
import { FormsModule} from '@angular/forms';

import { Routes, RouterModule } from '@angular/router';
import { CheckInComponent } from '../check-in/check-in/check-in.component';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FlightDetailsComponent } from '../check-in/flight-details/flight-details.component';
import { FlightListService } from '../services/flight-list.service';
import { PassengerDetailsComponent } from '../check-in/passenger-details/passenger-details.component';
import { PassengersListComponent } from '../check-in/passengers-list/passengers-list.component';
import { SeatComponent } from '../check-in/seat/seat.component';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { flightListReducer } from '../store/reducers/flightList.reducer';
import { FlightEffects } from '../store/effects/flightList.effects';

const routes: Routes = [
  {
    path: 'lazyModule',
    component: CheckInComponent
  },
  {
    path: 'lazyModule/:id',
    component: FlightDetailsComponent
  }
  // {
  //   path: '',
  //   redirectTo: '/lazyModule',
  //   pathMatch: 'full'
  // },
  // {
  //   path: 'lazyModule',
  //   children: [
  //     {
  //       path: '',
  //       component: CheckInComponent
  //     },
  //     {
  //       path: ':id',
  //       component: FlightDetailsComponent
  //     }
  //  ]
  // }

];

@NgModule({
  declarations: [
    CheckInComponent,
    FlightDetailsComponent,
    PassengersListComponent,
    PassengerDetailsComponent,
    SeatComponent
  ],
  imports: [
    MaterialModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    StoreModule.forRoot({
      flightState: flightListReducer,
    }),
    EffectsModule.forRoot([FlightEffects])

  ],
  // providers: [ FlightListService ],
  exports: [RouterModule]
})
export class LazyModule { }
