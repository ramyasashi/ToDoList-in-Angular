import { AccellaryServices } from './accellaryServices';

export class Passenger {
  name: string;
  age: number;
  flightId: number;
  mobileNumber: number;
  infants: boolean;
  accillaryServices: AccellaryServices;
  seatNumber: number;
  passport: string;
  address: string;
}
