import { Component, OnInit, Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { AdminService } from 'src/app/services/admin.service';
import { FlightListService } from 'src/app/services/flight-list.service';
import { Passenger } from 'src/app/Models/passenger';


export interface DialogData {
  name: string;
  passport: string;
  seatNumber: number;
  address: string;
}

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  passengersList: Passenger[];
  resultValue = [];
  constructor(  public adminservices: AdminService, public dialog: MatDialog, private flightListService: FlightListService) { }


  ngOnInit() {
    console.log('rhfb');
    this.flightListService.passengerSubject.subscribe(data => {
      // data.map(value => this.passengersList.push(value));
      this.passengersList = data;
    });
    // this.adminservices.adminsubject.subscribe( x => {
    //   for ( const i of x) {
    //     this.passlist.push(i);
    //   }
    //   console.log(this.passlist);

    // });
    this.flightListService.getPassengerList();
  }

  openDialog(data , index): void {
    // tslint:disable-next-line: no-use-before-declare
    const dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '250px',
      data: {
        partialData: data
      },
    });
    console.log(data);
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log( result );
      let i = 0;
      if (result) {
         for (const value of this.passengersList) {
          // console.log(i, index);
          if ( i === index) {
            this.passengersList[index].name = result.name;
            this.passengersList[index].passport = result.passport;
            this.passengersList[index].seatNumber = result.seatNumber;
            this.passengersList[index].address = result.address;
            // console.log(this.passengersList);
          }
          i++;
         }
        }
    });
  }
  delete(i) {
    this.passengersList.splice(i, 1);
  }
  openDialogForCreate() {
    // tslint:disable-next-line: no-use-before-declare
    const dialogRef = this.dialog.open(CreatePassenger, {
      width: '300px',
      data: null
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.resultValue = result;
    });
  }

}

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'dialog-overview-example-dialog',
  templateUrl: 'dialog-list-example.html',
})
// tslint:disable-next-line:component-class-suffix
export class DialogOverviewExampleDialog {
  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
 }

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'create-passenger',
  templateUrl: 'create-passenger.html',
})
// tslint:disable-next-line:component-class-suffix
export class CreatePassenger {

  selectedValue: string;
  foods = ['pizza', 'Burger', 'Sandwitch', 'Veg-roll', 'Double chease burger'];
  // PassengerData: any = {
  //   name : 'Sisira',
  //   age: 23,
  //   flightId: 1544,
  //   mobileNumber: 9876543215,
  //   infants: true,
  //   accillaryServices: {
  //     food: 'Veg-Roll',
  //     wheelChair: false,
  //     infants: true
  //   },
  //   seatNumber: 4,
  //   passport: 'A123F243',
  //   address: '#1,1st floor,sreekantam circle, bangalore, Karnataka-560030'
  // };
  user: Passenger = new Passenger();
  constructor(
    public dialogRef: MatDialogRef<CreatePassenger>,
    @Inject(MAT_DIALOG_DATA) public data: Passenger) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
 }
