import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListComponent, DialogOverviewExampleDialog, CreatePassenger } from './list/list.component';
import { MaterialModule } from '../material/material.module';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

const routes: Routes = [
  {
    path: 'adminModule',
    component: ListComponent
  }
];

@NgModule({
  declarations: [ListComponent, DialogOverviewExampleDialog, CreatePassenger],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    RouterModule.forChild(routes),
  ],
  exports: [RouterModule],
  entryComponents: [
    DialogOverviewExampleDialog, CreatePassenger
  ],
})
export class AdminModule { }
