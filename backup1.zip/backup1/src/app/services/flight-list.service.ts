import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { FLIGHTS } from '../Models/flight_data';
import { Passenger } from '../Models/passenger';
import { delay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FlightListService {

  flights = [];
  flightSubject = new Subject<FLIGHTS[]>();
  passengersList = [];
  passengerSubject = new Subject<Passenger[]>();
  url1 = 'assets/JSON_Files/passengers.json';
  constructor(private http: HttpClient) {
    console.log('FlightListService');
    this.getFlightList();
    this.getPassengerList();
   }

  url = 'assets/JSON_Files/flight_data.json';
  getFlightList(): Observable<any> {
    return  this.http.get(this.url).pipe(delay(100));
  }
  getPassengerList(): any {
    this.http.get(this.url1).subscribe((x: Passenger[]) => {
    this.passengersList = x;
    this.passengerSubject.next(this.passengersList);
    console.log(this.passengersList);
    });
  }
}
