import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seat',
  templateUrl: './seat.component.html',
  styleUrls: ['./seat.component.scss']
})
export class SeatComponent implements OnInit {

  bSeatUrl = './assets/bseat.png';
  fSeatUrl = './assets/fseat.png';
  bookSeatUrl = './assets/bookseat.png';
  num = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
  constructor() { }

  ngOnInit() {
  }

}
