import { Component, OnInit } from '@angular/core';
import { FlightListService } from 'src/app/services/flight-list.service';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-passenger-details',
  templateUrl: './passenger-details.component.html',
  styleUrls: ['./passenger-details.component.scss']
})
export class PassengerDetailsComponent implements OnInit {

  passengersList = [];
  id: number;
  passengerWF = [];
  subscription: Subscription;
  isCheckedIn = false;
  selectedValue: string;
  filterValues = ['wheelChair', 'infants'];
  constructor(private flightListService: FlightListService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.subscription = this.flightListService.passengerSubject.subscribe(data => {
      this.passengersList = data;
      this.id = +this.route.snapshot.paramMap.get('id');
      for (const person of this.passengersList) {
       if (person.flightId === this.id) {
        this.passengerWF.push(person);
       }
      }
      console.log(this.passengersList);
    });
  }
  filterFun(result: string) {
    console.log(result);
  }
}
