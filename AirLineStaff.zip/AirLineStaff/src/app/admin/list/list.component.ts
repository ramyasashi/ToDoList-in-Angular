import { Component, OnInit, Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { AdminService } from 'src/app/services/admin.service';
import { FlightListService } from 'src/app/services/flight-list.service';
import { Passenger } from 'src/app/Models/passenger';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import * as PassengerActions from '../../store/actions/passengerList.action';
import { AppState } from '../../store/app.state';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  passengersList$: Observable<Passenger[]>;
  passengersList: Passenger[];
  resultValue = [];
  constructor(
    public adminservices: AdminService,
    public dialog: MatDialog, private flightListService: FlightListService, private store: Store<AppState>, private router: Router) { }


  ngOnInit() {
    this.passengersList$ = this.store.pipe(select(store => store.passengerState.list));
    this.store.dispatch(new PassengerActions.PassengerList());
    this.displayList();
  }
  displayList() {
    this.passengersList$.subscribe(data => this.passengersList = data);
    console.log(this.passengersList);
    this.flightListService.getPassengerList();
  }
  openDialog(data , index): void {
    // tslint:disable-next-line: no-use-before-declare
    const dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '250px',
      data: {
        partialData: data
      },
    });
    console.log(data);
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log( 'result is', result );
      if (result) {
        data.name = result.name;
        data.passport = result.passport;
        data.seatNumber = result.seatNumber;
        data.address = result.address;
        this.flightListService.updateValue(data).subscribe(data1 => console.log(data1));
      }
    });
  }
  delete(d) {
    console.log('delete fun');
    this.flightListService.Delete(d).subscribe(data1 => this.ngOnInit());
  }

}

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'dialog-overview-example-dialog',
  templateUrl: 'dialog-list-example.html',
})
// tslint:disable-next-line:component-class-suffix
export class DialogOverviewExampleDialog {
  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: Passenger) {}

    onNoThanksClick(): void {
    this.dialogRef.close();
  }
 }
