import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListComponent, DialogOverviewExampleDialog } from './list/list.component';
import { MaterialModule } from '../material/material.module';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CreateComponent } from './create/create.component';

const routes: Routes = [
  {
    path: 'adminModule',
    component: ListComponent
  },
  {
    path: 'create',
    component: CreateComponent
  }
];

@NgModule({
  declarations: [ListComponent, DialogOverviewExampleDialog, CreateComponent],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
  ],
  exports: [RouterModule],
  entryComponents: [
    DialogOverviewExampleDialog
  ],
})
export class AdminModule { }
