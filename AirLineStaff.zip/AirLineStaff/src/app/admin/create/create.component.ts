import { Component, OnInit } from '@angular/core';
import { Passenger } from 'src/app/Models/passenger';
import { FlightListService } from 'src/app/services/flight-list.service';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreateComponent implements OnInit {

  name: string;
  // id: number;
  // age: number;
  // flightId: number;
  // mobileNumber: number;
  // infants: boolean;
  // isCheckedIn: boolean;
  // food: string;
  // wheelChair: boolean;
  // seatNumber: number;
  // passport: string;
  // address: string;
  // user = {
  //   name: this.name,
  //   id: this.id,
  //   age: this.age,
  //   flightId: this.flightId,
  //   mobileNumber: this.mobileNumber,
  //   isCheckedIn: this.isCheckedIn,
  //   accillaryServices: {
  //     food: this.food,
  //     wheelChair: this.wheelChair,
  //     infants: this.infants,
  //   },
  //   seatNumber: this.seatNumber,
  //   passport: this.passport,
  //   address: this.address
  // };
  user: Passenger = new Passenger();
  registerForm: FormGroup;
  // foods = ['pizza', 'Burger', 'Sandwitch', 'Veg-roll', 'Double chease burger'];
  constructor(private service: FlightListService, public router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      name: ['', [
      Validators.required,
      Validators.minLength(6)
    ]],
    age: ['', [
      Validators.required,
      Validators.maxLength(2)
    ]],
    flightId: ['', [
      Validators.required,
    ]],
    mobileNumber: ['', [
      Validators.required,
      Validators.pattern(/^[6-9]\d{9}$/)
    ]],
    isCheckedIn: ['true', [
      Validators.required,
    ]],
    accillaryServices: this.formBuilder.group({
      food: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      wheelChair: ['true', [
        Validators.required,
      ]],
      infants: ['true', [
        Validators.required,
      ]],
    }),
    seatNumber: ['', [
      Validators.required,
      Validators.pattern(/^[0-9]{2}$/)
    ]],
    passport: ['', [
      Validators.required,
    ]],
    address: ['', [
      Validators.required,
    ]],
  });

  }
  addPassenger(regForm: FormGroup) {
    console.log('form data', regForm.value);
    this.service.postPassenger(regForm.value).subscribe(data1 => this.router.navigate(['/adminModule']));
    console.log('after add');
  }
}
