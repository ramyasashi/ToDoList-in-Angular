import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MaterialModule } from '../material/material.module';
import { FormsModule} from '@angular/forms';

import { Routes, RouterModule } from '@angular/router';
import { CheckInComponent } from '../check-in/check-in/check-in.component';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FlightDetailsComponent } from '../check-in/flight-details/flight-details.component';
import { FlightListService } from '../services/flight-list.service';
import { PassengerDetailsComponent } from '../check-in/passenger-details/passenger-details.component';
import { SeatComponent } from '../check-in/seat/seat.component';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { FlightListReducer } from '../store/reducers/flightList.reducer';
import { FlightEffects } from '../store/effects/flightList.effects';
import { PassengerListReducer } from '../store/reducers/passengerList.reducer';
import { PassengerEffects } from '../store/effects/passengerList.effects';
import { InflightComponent, PopUpExampleDialogComponent } from '../check-in/inflight/inflight.component';
import { FlightListComponent } from '../check-in/flight-list/flight-list.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';

const routes: Routes = [
  {
    path: 'lazyModule',
    component: CheckInComponent
  },
  {
    path: 'lazyModule/:id',
    component: FlightDetailsComponent
  }
  // {
  //   path: '',
  //   redirectTo: '/lazyModule',
  //   pathMatch: 'full'
  // },
  // {
  //   path: 'lazyModule',
  //   children: [
  //     {
  //       path: '',
  //       component: CheckInComponent
  //     },
  //     {
  //       path: ':id',
  //       component: FlightDetailsComponent
  //     }
  //  ]
  // }

];

@NgModule({
  declarations: [
    CheckInComponent,
    FlightDetailsComponent,
    PassengerDetailsComponent,
    SeatComponent,
    InflightComponent,
    FlightListComponent,
    PopUpExampleDialogComponent
  ],
  imports: [
    MaterialModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    Ng2SearchPipeModule,
    StoreModule.forRoot({
      flightState: FlightListReducer,
      passengerState: PassengerListReducer
    }),
    EffectsModule.forRoot([FlightEffects, PassengerEffects]),
    // StoreModule.forRoot({
    //   passengerState: PassengerListReducer,
    // }),
    // EffectsModule.forRoot([PassengerEffects])

  ],
  entryComponents: [
    PopUpExampleDialogComponent
  ],
  // providers: [ FlightListService ],
  exports: [RouterModule],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class LazyModule { }
