import { Component, OnInit } from '@angular/core';
import { FlightListService } from 'src/app/services/flight-list.service';
import { ActivatedRoute } from '@angular/router';
import { Subscription, Observable } from 'rxjs';
import { Passenger } from 'src/app/Models/passenger';
import { Store, select } from '@ngrx/store';
import * as PassengerActions from '../../store/actions/passengerList.action';
import { AppState } from '../../store/app.state';

@Component({
  selector: 'app-passenger-details',
  templateUrl: './passenger-details.component.html',
  styleUrls: ['./passenger-details.component.scss']
})
export class PassengerDetailsComponent implements OnInit {

  passengersList = [];
  passengerList$: Observable<Passenger[]>;
  id: number;
  passengerWF = new Array();
  passengerWF1 = new Array();
  subscription: Subscription;
  isCheckedIn = true;
  selectedValue: string;
  filterValues = ['wheelChair', 'infants'];
  element: HTMLElement;
  color = 'primary';
  constructor(private flightListService: FlightListService, private route: ActivatedRoute, private store: Store<AppState>) { }

  ngOnInit() {
    this.id = +this.route.snapshot.paramMap.get('id');
    this.passengerList$ = this.store.pipe(select(store => store.passengerState.list));
    this.store.dispatch(new PassengerActions.PassengerList());
    // this.displayPassengers();
    this.passengerList$.subscribe(data => {
        this.passengersList = data;
        console.log('passengerList:', this.passengersList);
        this.passengerWF = [];
        for (const person of this.passengersList) {
          if (person.flightId === this.id) {
          // console.log('person', person);
          this.passengerWF.push(person);
          // console.log(this.passengerWF);
          }
        }
        console.log(this.passengerWF);
        return this.passengerWF;
      });
  }
  filterFun(result: string) {
    console.log(result);
    if ( result === undefined) {
      console.log('filtering didt happened');
    } else {
      for (const passenger of this.passengerWF) {
        if ((result === 'infants') && (passenger.accillaryServices.infants === true)) {
          // console.log('passenger.result', passenger.result);
          this.passengerWF1.push(passenger);
        } else if ((result === 'wheelChair') && (passenger.accillaryServices.wheelChair === true)) {
          this.passengerWF1.push(passenger);
        } else {
          this.passengerWF = this.passengerWF;
        }
      }
      this.passengerWF = this.passengerWF1;
      console.log('after sorting', this.passengerWF1);
    }
  }
  updatingValue(passenger: Passenger) {
    passenger.isCheckedIn = true;
    // console.log('after checkedIn', passenger);
    this.flightListService.updateValue(passenger).subscribe(data1 => console.log(data1));
  }
}
