import { Component, OnInit, OnDestroy } from '@angular/core';
import { FlightListService } from 'src/app/services/flight-list.service';
import { Subscription, Observable } from 'rxjs';
import { FLIGHTS } from 'src/app/Models/flight_data';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import * as FlightActions from '../../store/actions/flightList.action';
import { AppState } from '../../store/app.state';

@Component({
  selector: 'app-check-in',
  templateUrl: './check-in.component.html',
  styleUrls: ['./check-in.component.scss']
})
export class CheckInComponent implements OnInit, OnDestroy {

  flightList$: Observable<FLIGHTS[]>;
  flightList = [];
  subscription: Subscription;

  constructor(private flightListService: FlightListService, private router: Router, private store: Store<AppState> ) { }

  ngOnInit() {
//       this.flightList$ = this.store.pipe(select(store => store.flightState.list));
//       this.store.dispatch(new FlightActions.FlightList());
//       this.flightList$.subscribe(data => this.flightList = data);
//       console.log(this.flightList);
  }
  // redirectToFD(id) {
  //   this.router.navigate(['/lazyModule/', id]);
  // }
  ngOnDestroy() {
   // this.subscription.unsubscribe();
  }
}
