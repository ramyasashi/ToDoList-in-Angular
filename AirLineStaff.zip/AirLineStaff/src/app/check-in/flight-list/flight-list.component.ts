import { Component, OnInit, OnDestroy } from '@angular/core';
import { FlightListService } from 'src/app/services/flight-list.service';
import { Subscription, Observable } from 'rxjs';
import { FLIGHTS } from 'src/app/Models/flight_data';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import * as FlightActions from '../../store/actions/flightList.action';
import { AppState } from '../../store/app.state';

@Component({
  selector: 'app-flight-list',
  templateUrl: './flight-list.component.html',
  styleUrls: ['./flight-list.component.scss']
})
export class FlightListComponent implements OnInit, OnDestroy {

  flightList$: Observable<FLIGHTS[]>;
  flightList = [];
  subscription: Subscription;
  searchText: string;
  constructor(private flightListService: FlightListService, private router: Router, private store: Store<AppState> ) { }

  ngOnInit() {
    this.flightList$ = this.store.pipe(select(store => store.flightState.list));
    this.store.dispatch(new FlightActions.FlightList());
    this.flightList$.subscribe(data => this.flightList = data);
    console.log(this.flightList);
  }
  ngOnDestroy() {
    // this.subscription.unsubscribe();
   }
   filterFun() {
    if (this.searchText === '') {
      this.flightList = this.flightList;
    } else {
      this.flightList = this.flightList.filter((category) => {
        return category.name.toLowerCase().indexOf(this.searchText.toLowerCase()) > -1;
      });
    }
   }
}
