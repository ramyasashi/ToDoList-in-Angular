import { Component, OnInit, Inject } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { FLIGHTS } from 'src/app/Models/flight_data';
import { Store, select } from '@ngrx/store';
import * as FlightActions from '../../store/actions/flightList.action';
import { AppState } from '../../store/app.state';
import { FlightListService } from 'src/app/services/flight-list.service';
import { ActivatedRoute } from '@angular/router';
import { Passenger } from 'src/app/Models/passenger';
import * as PassengerActions from '../../store/actions/passengerList.action';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

export interface DialogData {
  food: string;
  infants: boolean;
  wheelChair: boolean;
}
@Component({
  selector: 'app-inflight',
  templateUrl: './inflight.component.html',
  styleUrls: ['./inflight.component.scss']
})
export class InflightComponent implements OnInit {

  id: number;
  flightList$: Observable<FLIGHTS[]>;
  flightList = [];
  subscription: Subscription;
  flight: FLIGHTS;
  passengersList = [];
  passengerList$: Observable<Passenger[]>;
  passengerWF = new Array();
  resultValue: string;
  constructor(
  private flightListService: FlightListService,
  private route: ActivatedRoute,
  private store: Store<AppState>, public dialog: MatDialog ) { }

  ngOnInit() {
    this.id = +localStorage.getItem('id');
    console.log(this.id);
    this.flightList$ = this.store.pipe(select(store => store.flightState.list));
    this.store.dispatch(new FlightActions.FlightList());
    this.flightList$.subscribe(data => {
      this.flightList = data;
      this.flightList.map(value => {
        if (value.id === this.id) {
        this.flight = value;
        console.log(this.flight);
        return this.flight;
        }
      });
      // this.flightListService.getFlightList();
    });
    this.id = +this.route.snapshot.paramMap.get('id');
    this.passengerList$ = this.store.pipe(select(store => store.passengerState.list));
    this.store.dispatch(new PassengerActions.PassengerList());
    // this.displayPassengers();
    this.passengerList$.subscribe(data => {
        this.passengersList = data;
        console.log('passengerList:', this.passengersList);
        this.passengerWF = [];
        for (const person of this.passengersList) {
          if (person.flightId === this.id) {
          // console.log('person', person);
          this.passengerWF.push(person);
          // console.log(this.passengerWF);
          }
        }
        console.log(this.passengerWF);
        return this.passengerWF;
      });
  }

  addAccillary(data1): void {
      // tslint:disable-next-line: no-use-before-declare
      const dialogRef = this.dialog.open(PopUpExampleDialogComponent, {
        width: '250px',
        data: data1
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
        this.resultValue = result;
      });
  }
}
@Component({
  selector: 'app-pop-up-example-dialog',
  templateUrl: 'pop-up-example-dialog.html',
})
export class PopUpExampleDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<PopUpExampleDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

}
