import { Component, OnInit, OnDestroy } from '@angular/core';
import { FlightListService } from 'src/app/services/flight-list.service';
import { Subscription, Observable } from 'rxjs';
import { FLIGHTS } from 'src/app/Models/flight_data';
import { ActivatedRoute, ParamMap, Params } from '@angular/router';
import { Store, select } from '@ngrx/store';
import * as FlightActions from '../../store/actions/flightList.action';
import { AppState } from '../../store/app.state';

@Component({
  selector: 'app-flight-details',
  templateUrl: './flight-details.component.html',
  styleUrls: ['./flight-details.component.scss']
})
export class FlightDetailsComponent implements OnInit {

  flightList$: Observable<FLIGHTS[]>;
  flightList = [];
  subscription: Subscription;
  flight: FLIGHTS;
  id: number;
  constructor(private flightListService: FlightListService, private route: ActivatedRoute,  private store: Store<AppState> ) { }

  ngOnInit() {
    console.log('detail component');
    this.id = +this.route.snapshot.paramMap.get('id');
    localStorage.setItem('id', `${this.id}`);
    this.flightList$ = this.store.pipe(select(store => store.flightState.list));
    this.store.dispatch(new FlightActions.FlightList());
    this.flightList$.subscribe(data => {
      this.flightList = data;
      this.flightList.map(value => {
        if (value.id === this.id) {
        this.flight = value;
        console.log(this.flight);
        return this.flight;
        }
      });
    });
  }

}
