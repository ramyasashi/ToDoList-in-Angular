import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { SigninComponent } from '../signin/signin.component';
import { User } from 'src/app/Models/user';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  user: User = new User();
  hide = true;

  registerForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private router: Router, public dialog: MatDialog) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      fName: ['', [
      Validators.required,
      Validators.minLength(4)
      ]],
      lName: ['', [
        Validators.required,
        Validators.minLength(4)
      ]],
      email: ['', [
        Validators.required,
        Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/)
      ]],
      password: ['', [
        Validators.required,
        Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/)
      ]],
      mobileNumber: ['', [
        Validators.required,
        Validators.pattern(/^[6-9]\d{9}$/)
      ]],
    });

  }
  onSubmit(regForm: FormGroup) {
    const emailInput = regForm.get('email').value;
    const passwordInput = regForm.get('password').value;

    localStorage.setItem('email', emailInput);
    localStorage.setItem('password', passwordInput);
    const dialogRef = this.dialog.open(SigninComponent);
    alert('Registration Successfull !!');
    this.router.navigate(['/signin']);
  }

}
