import * as PassengerActions from '../../store/actions/passengerList.action';

export interface PassengerState {
  list: any[];
  loading: boolean;
  error: Error;
  login: {};
}
const initialState: PassengerState = {
  list: [],
  loading: false,
  error: null,
  login: {}
  };
export function PassengerListReducer( state = initialState, action: PassengerActions.PassengerActions) {
    switch ( action.type ) {
      case  PassengerActions.PassengerListActionTypes.GET_PASSENGER_LIST: {
        return {...state, loading: true};
      }
      case  PassengerActions.PassengerListActionTypes.GET_PASSENGER_LIST_SUCCESS: {
        return {...state, list: action.payload, loading: true};
      }
      case  PassengerActions.PassengerListActionTypes.GET_PASSENGER_LIST_ERROR: {
        return {...state, error: action.payload, loading: true};
      }
      default:
        return state;
    }
  }
