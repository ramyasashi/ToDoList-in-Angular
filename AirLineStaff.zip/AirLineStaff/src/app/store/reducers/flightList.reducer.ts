import * as FlightActions from '../../store/actions/flightList.action';

export interface FlightState {
  list: any[];
  loading: boolean;
  error: Error;
  login: {};
}
const initialState: FlightState = {
  list: [],
  loading: false,
  error: null,
  login: {}
  };
export function FlightListReducer( state = initialState, action: FlightActions.FlightActions) {
    switch ( action.type ) {
      case  FlightActions.FlightListActionTypes.GET_FLIGHT_LIST: {
        return {...state, loading: true};
      }
      case  FlightActions.FlightListActionTypes.GET_FLIGHT_LIST_SUCCESS: {
        return {...state, list: action.payload, loading: true};
      }
      case  FlightActions.FlightListActionTypes.GET_FLIGHT_LIST_ERROR: {
        return {...state, error: action.payload, loading: true};
      }
      default:
        return state;
    }
  }
