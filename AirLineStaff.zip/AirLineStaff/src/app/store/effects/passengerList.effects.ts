import { Injectable } from '@angular/core';
import { Actions, Effect , ofType } from '@ngrx/effects';
import { Observable, of} from 'rxjs';
import * as PassengerActions from '../../store/actions/passengerList.action';
import { FlightListService } from '../../services/flight-list.service';
import { mergeMap, map, catchError } from 'rxjs/operators';
import { FLIGHTS } from '../../Models/flight_data';
import { User } from '../../Models/user';

@Injectable()
export class PassengerEffects {
  constructor(
    private actions$: Actions,
    private flightService: FlightListService
  ) {}
  @Effect() getPassengerList$ = this.actions$
  .pipe(ofType<PassengerActions.PassengerList>(PassengerActions.PassengerListActionTypes.GET_PASSENGER_LIST),
  mergeMap(
    () =>
      this.flightService.getPassengerList().pipe(
        map(data => new PassengerActions.PassengerListSuccess(data)),
        catchError(error => of(new PassengerActions.PassengerListError(error))))
  )
  );
}
