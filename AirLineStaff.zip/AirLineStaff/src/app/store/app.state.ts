import { FlightState } from './store/../reducers/flightList.reducer';
import { PassengerState } from './reducers/passengerList.reducer';

export interface AppState {
  flightState: FlightState;
  passengerState: PassengerState;
}
