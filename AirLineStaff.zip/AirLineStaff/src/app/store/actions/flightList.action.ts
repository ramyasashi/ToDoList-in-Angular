import { Action } from '@ngrx/store';
import { FLIGHTS } from 'src/app/Models/flight_data';

export enum FlightListActionTypes {
  GET_FLIGHT_LIST = '[FLIGHTS] GET_FLIGHT_LIST',
  GET_FLIGHT_LIST_SUCCESS = '[FLIGHTS] GET_FLIGHT_LIST_SUCCESS',
  GET_FLIGHT_LIST_ERROR = '[FLIGHTS] GET_FLIGHT_LIST_ERROR'
}

export class FlightList implements Action {
  readonly type = FlightListActionTypes.GET_FLIGHT_LIST;
  constructor() { }
}
export class FlightListSuccess implements Action {
  readonly type = FlightListActionTypes.GET_FLIGHT_LIST_SUCCESS;
  constructor(public payload: FLIGHTS[]) { }
}
export class FlightListError implements Action {
  readonly type = FlightListActionTypes.GET_FLIGHT_LIST_ERROR;
  constructor(public payload: Error) { }
}

export type FlightActions = FlightList | FlightListSuccess | FlightListError;
