import { Action } from '@ngrx/store';
import { Passenger } from 'src/app/Models/passenger';

export enum PassengerListActionTypes {
  GET_PASSENGER_LIST = '[FLIGHTS] GET_PASSENGER_LIST',
  GET_PASSENGER_LIST_SUCCESS = '[FLIGHTS] GET_PASSENGER_LIST_SUCCESS',
  GET_PASSENGER_LIST_ERROR = '[FLIGHTS] GET_PASSENGER_LIST_ERROR'
}

export class PassengerList implements Action {
  readonly type = PassengerListActionTypes.GET_PASSENGER_LIST;
  constructor() { }
}
export class PassengerListSuccess implements Action {
  readonly type = PassengerListActionTypes.GET_PASSENGER_LIST_SUCCESS;
  constructor(public payload: Passenger[]) { }
}
export class PassengerListError implements Action {
  readonly type = PassengerListActionTypes.GET_PASSENGER_LIST_ERROR;
  constructor(public payload: Error) { }
}

export type PassengerActions = PassengerList | PassengerListSuccess | PassengerListError;
