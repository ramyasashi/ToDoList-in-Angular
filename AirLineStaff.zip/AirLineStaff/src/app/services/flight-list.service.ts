import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { FLIGHTS } from '../Models/flight_data';
import { Passenger } from '../Models/passenger';
import { delay } from 'rxjs/operators';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FlightListService {

  flights = [];
  flightSubject = new Subject<FLIGHTS[]>();
  passengersList = [];
  passengerSubject = new Subject<Passenger[]>();
  url1 = 'http://localhost:3000/passengers';
  constructor(private http: HttpClient) {
    console.log('FlightListService');
    this.getFlightList();
    this.getPassengerList();
   }

  url = 'http://localhost:3000/flight_data';
  // url = 'C:/Users/M9011981/Documents/Angular-201/angular201/db.json.flight_data';
  getFlightList(): Observable<any> {
    return  this.http.get(this.url).pipe(delay(100));
  }
  getPassengerList(): Observable<any> {
    return this.http.get(this.url1).pipe(delay(100));
  }
  updateValue(p: Passenger) {
    console.log('updateService');
    return this.http.put(this.url1 + '/' + p.id, p);
  }
  postPassenger(data: Passenger) {
    return this.http.post(this.url1, (data));
  }
  Delete(data) {
    console.log('delete in service');
    // return this.http.delete(`http://localhost:3000/passengers/${data.id}`);
    return this.http.delete(this.url1 + '/' + data.id);
  }
}
