import { TestBed } from '@angular/core/testing';

import { FlightListService } from './flight-list.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FLIGHTS } from '../Models/flight_data';
import { Passenger } from '../Models/passenger';

describe('FlightListService', () => {
  let flightListservice: FlightListService;
  let httpMock: HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [FlightListService]
  }),
  flightListservice = TestBed.get(FlightListService);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    const service: FlightListService = TestBed.get(FlightListService);
    expect(service).toBeTruthy();
  });
  it('should have getFlightList function', () => {
    const service: FlightListService = TestBed.get(FlightListService);
    expect(service.getFlightList).toBeTruthy();
  });
  it('should have getPassengerList function', () => {
    const service: FlightListService = TestBed.get(FlightListService);
    expect(service.getPassengerList).toBeTruthy();
  });
  it('should have updateValue function', () => {
    const service: FlightListService = TestBed.get(FlightListService);
    expect(service.updateValue).toBeTruthy();
  });
  it('be able to retrieve flight list from the API via GET', () => {
    const dummyPosts: FLIGHTS[] = [{
      name: 'ramya',
      id: 1,
      image: '/assets/airasia.png',
      arrivalTime: '4:45AM',
      departureTime: '3:34AM',
      from: 'bangaluru',
      to: 'hyderabad',
    }, {
      name: 'raghu',
      id: 2,
      image: '/assets/spicejet.png',
      arrivalTime: '3:20AM',
      departureTime: '5:50AM',
      from: 'bangaluru',
      to: 'hyderabad',
    }];
    flightListservice.getFlightList().subscribe(posts => {
        expect(posts.length).toBe(2);
        expect(posts).toEqual(dummyPosts);
    });
    const request = httpMock.expectOne( `${flightListservice.url}`);
    expect(request.request.method).toBe('GET');
    request.flush(dummyPosts);
  });
  it('be able to retrieve passenger list from the API via GET', () => {
    const dummyPosts1: Passenger[] = [{
      name: 'ramya',
      id: 1,
      age: 23,
      flightId: 1543,
      mobileNumber: 9876543210,
      isCheckedIn: false,
      accillaryServices: {
        food: 'Burger',
        wheelChair: true,
        infants: true
      },
      seatNumber: 14,
      passport: 'A123F243',
      address: '#1,1st floor,sreekantam circle, bangalore, Karnataka-560030',
    }, {
      name: 'raghu',
      id: 2,
      age: 23,
      flightId: 1544,
      mobileNumber: 9876543211,
      isCheckedIn: false,
      accillaryServices: {
        food: 'Burger',
        wheelChair: true,
        infants: true
      },
      seatNumber: 13,
      passport: 'A123F241',
      address: '#1,1st floor,sreekantam circle, bangalore, Karnataka-560030',
    }];
    flightListservice.getPassengerList().subscribe(posts => {
        expect(posts.length).toBe(2);
        expect(posts).toEqual(dummyPosts1);
    });
    const request = httpMock.expectOne( `${flightListservice.url1}`);
    expect(request.request.method).toBe('GET');
    request.flush(dummyPosts1);
  });
  it('be able to adding passenger to the list via POST', () => {
    const dummyPosts2: Passenger = {
      name: 'ramya',
      id: 1,
      age: 23,
      flightId: 1543,
      mobileNumber: 9876543210,
      isCheckedIn: false,
      accillaryServices: {
        food: 'Burger',
        wheelChair: true,
        infants: true
      },
      seatNumber: 14,
      passport: 'A123F243',
      address: '#1,1st floor,sreekantam circle, bangalore, Karnataka-560030',
    };
    flightListservice.postPassenger(dummyPosts2).subscribe(posts => {
        // expect(posts.length).toBe(1);
        expect(posts).toEqual(dummyPosts2);
    });
    const request = httpMock.expectOne( `${flightListservice.url1}`);
    expect(request.request.method).toBe('POST');
    request.flush(dummyPosts2);
  });

  afterEach(() => {
    httpMock.verify();
  });
});
