import { AccellaryServices } from './accellaryServices';

export class Passenger {
  name: string;
  id: number;
  age: number;
  flightId: number;
  mobileNumber: number;
  isCheckedIn: boolean;
  accillaryServices: AccellaryServices;
  seatNumber: number;
  passport: string;
  address: string;
}
